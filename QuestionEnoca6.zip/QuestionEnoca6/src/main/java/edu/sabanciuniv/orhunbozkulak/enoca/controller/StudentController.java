package edu.sabanciuniv.orhunbozkulak.enoca.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.sabanciuniv.orhunbozkulak.enoca.entity.Student;
import edu.sabanciuniv.orhunbozkulak.enoca.service.StudentService;


@RestController
@RequestMapping(path = "/api")
public class StudentController {
	
	@Autowired
	private StudentService service;
	
	//takes post http method 
	@PostMapping("/addStudent")
	public Student addStudent(@RequestBody Student student) {
		return service.saveStudent(student);
	}

	//takes post http method
	@PostMapping("/addStudents")
	public List<Student> addStudents(@RequestBody List<Student> students) {
		return service.saveStudents(students);
	}

	//takes get http method
	@GetMapping("/students")
	public List<Student> findAllStudent(){
		return service.getStudents();
	}
	
	//takes get http method
	@GetMapping("/studentById/{id}")
	public Student findStudentById(@PathVariable int id) {
		return service.getStudentById(id);
	}
	
	//takes put http method
	@PutMapping("/updateStudent")
	public Student updateStudent(@RequestBody Student student) {
		return service.updateStudent(student);
	}
	
	//takess delete http method
	@DeleteMapping("/delete/{id}")
	public String deleteStudent(@PathVariable int id) {
		return service.deleteStudent(id);
	}
	
	
	
	
	
}

