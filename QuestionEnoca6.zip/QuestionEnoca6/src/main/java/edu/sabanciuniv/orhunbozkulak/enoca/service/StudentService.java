package edu.sabanciuniv.orhunbozkulak.enoca.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.sabanciuniv.orhunbozkulak.enoca.entity.Student;
import edu.sabanciuniv.orhunbozkulak.enoca.repository.StudentRepository;


@Service
public class StudentService {

	@Autowired
	private StudentRepository repo;
	
	
	public Student saveStudent(Student student) {
		return repo.save(student);
	}
	
	
	public List<Student> saveStudents(List<Student> students) { 
		return repo.saveAll(students);
	}
	
	public List<Student> getStudents() {
		return repo.findAll();
	}
	
	public Student getStudentById(int id) {
		return repo.findById(id).orElse(null);
	}
	
	public String deleteStudent(int id) {
		repo.deleteById(id);
		return "Student removed";
	}
	
	public Student updateStudent(Student student) {
		Student stu = repo.findById(student.getId()).orElse(null);
		stu.setName(student.getName());
		stu.setLName(student.getLName());
		stu.setAge(student.getAge());
		return repo.save(stu);
	}
	
}
