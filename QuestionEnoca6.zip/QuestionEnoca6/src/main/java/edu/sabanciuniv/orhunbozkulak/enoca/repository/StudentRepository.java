package edu.sabanciuniv.orhunbozkulak.enoca.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.sabanciuniv.orhunbozkulak.enoca.entity.Student;


public interface StudentRepository extends JpaRepository<Student, Integer>{

}
