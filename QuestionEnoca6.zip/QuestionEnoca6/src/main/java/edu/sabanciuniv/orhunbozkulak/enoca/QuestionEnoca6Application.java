package edu.sabanciuniv.orhunbozkulak.enoca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuestionEnoca6Application {

	public static void main(String[] args) {
		SpringApplication.run(QuestionEnoca6Application.class, args);
	}

}
