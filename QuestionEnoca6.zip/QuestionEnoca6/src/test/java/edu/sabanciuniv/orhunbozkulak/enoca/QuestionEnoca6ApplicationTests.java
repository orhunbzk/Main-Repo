package edu.sabanciuniv.orhunbozkulak.enoca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuestionEnoca6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
