﻿using System;
using System.Collections.Generic;

namespace Question2API.Model
{
    public class Hes
    {
        public int Id { get; set; }
        public String Hescode { get; set; }
        public String Status { get; set; }
    }
}
