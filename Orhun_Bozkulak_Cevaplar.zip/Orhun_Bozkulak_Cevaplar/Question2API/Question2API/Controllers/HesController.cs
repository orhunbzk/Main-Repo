﻿using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Question2API.Service;
using Question2API.Model;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Question2API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class HesController : ControllerBase
    {

        private ILogger _logger;
        private IHesService _service;

        public HesController(ILogger<HesController> logger, IHesService service)
        {
            _logger = logger;
            _service = service;
        }


        [HttpPost("/api/hes/dogrula")]
        //public void Post([FromBody]List<Hes> hes) 
        public ActionResult<Hes> Dogrula([FromBody]Hes hes)
        {

            _service.Dogrula(hes);
            return hes;
        }
    }
}
