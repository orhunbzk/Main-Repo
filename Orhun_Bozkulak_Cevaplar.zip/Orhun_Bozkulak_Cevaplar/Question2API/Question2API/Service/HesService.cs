﻿using System;
using System.Collections.Generic;
using Question2API.Model;
using Question2API.Service;

namespace Question2API.Service
{
    public class HesService: IHesService
    {
        private List<Hes> _hesItems;

        public HesService()
        {
            _hesItems = new List<Hes>();
        }

        //return basic json
        public List<Hes> Dogrula(Hes hesItem)
        {

            if(hesItem.Hescode != null)
            {
                //decision logic goes here.. 
                if (hesItem.Hescode.EndsWith("x"))
                {
                    hesItem.Status = "Risky";
                }
                else
                {
                    hesItem.Status = "Riskless";
                }

            }
            else
            {
                //if null new. 
                hesItem = new Hes();

            }

            _hesItems.Add(hesItem);
            return _hesItems;
        }

    }
}
