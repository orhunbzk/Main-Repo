﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Question2API.Model;

namespace Question2API.Service
{
    public interface IHesService
    {
        public List<Hes> Dogrula(Hes hesCode);

    }
}
