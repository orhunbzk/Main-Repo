package main;

public class CalculationMainClass {

	public static void main(String[] args) {

		int xParalell = 0;
		int yParalell = 0;

		int[][] points = { { 1, 2 }, { 3, 7 }, { 0, 6 }, { 1, 1 }, { -5, 2 }, { 1, 5 }, { 3, 5 } };

		System.out.println(points.length);

		for (int i = 0; i < points.length; i++) {
			for (int j = i + 1; j < points.length; j++) {
				if (xParalell(points[i], points[j]))
					xParalell++;
				if (yParalell(points[i], points[j]))
					yParalell++;
			}
		}

		System.out.println("X parallel: " + xParalell);
		System.out.println("Y parallel: " + yParalell);

	}

	public static boolean xParalell(int[] point1, int[] point2) {
		return point1[1] == point2[1];
	}

	public static boolean yParalell(int[] point1, int[] point2) {
		return point1[0] == point2[0];
	}

}
