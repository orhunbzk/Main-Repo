﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Question3MVC.Models;

namespace Question3MVC.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public JsonResult Index(string firstName, string lastName, string date, int age, string city)
        {
            string name = string.Format("Name: {0} {1} {2} {3} {4} ", firstName, lastName, date, age, city );
            return Json(new { Status = "success", Name = name });
        }
    }
}
